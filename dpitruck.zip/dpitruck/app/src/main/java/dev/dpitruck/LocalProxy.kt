package dev.dpitruck

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

/** Локальный HTTP CONNECT-прокси. Первый пакет TLS отправляет наружу через Desync. */
class LocalProxy(private val strategy: () -> Strategy) {

    private var server: ServerSocket? = null
    val port: Int get() = server?.localPort ?: 0

    fun start(listenPort: Int) {
        val s = ServerSocket(listenPort, 50, InetAddress.getByName("127.0.0.1"))
        server = s
        thread(isDaemon = true) {
            while (!s.isClosed) {
                try {
                    val c = s.accept()
                    thread(isDaemon = true) { handle(c) }
                } catch (_: Exception) {
                    break
                }
            }
        }
    }

    fun stop() {
        try {
            server?.close()
        } catch (_: Exception) {
        }
    }

    private fun readHeaders(input: InputStream): String? {
        val buf = ByteArrayOutputStream()
        var last4 = 0
        while (buf.size() < 8192) {
            val b = input.read()
            if (b < 0) return null
            buf.write(b)
            last4 = (last4 shl 8) or b
            if (last4 == 0x0D0A0D0A) return buf.toString("ISO-8859-1")
        }
        return null
    }

    /** Читает первый пакет клиента; для TLS дочитывает запись целиком. */
    private fun readFirst(input: InputStream): ByteArray? {
        val buf = ByteArray(20000)
        var n = input.read(buf)
        if (n <= 0) return null
        if (buf[0].toInt() == 0x16 && n >= 5) {
            val need = 5 + (((buf[3].toInt() and 0xFF) shl 8) or (buf[4].toInt() and 0xFF))
            while (n < need && n < buf.size) {
                val m = input.read(buf, n, minOf(need, buf.size) - n)
                if (m <= 0) break
                n += m
            }
        }
        return buf.copyOf(n)
    }

    private fun handle(client: Socket) {
        var upstream: Socket? = null
        try {
            client.soTimeout = 15000
            val cin = client.getInputStream()
            val cout = client.getOutputStream()
            val head = readHeaders(cin) ?: return
            val first = head.lineSequence().firstOrNull() ?: return
            val parts = first.split(" ")
            if (parts.size < 2 || parts[0] != "CONNECT") {
                cout.write("HTTP/1.1 405 Method Not Allowed\r\n\r\n".toByteArray())
                return
            }
            val target = parts[1]
            val idx = target.lastIndexOf(':')
            val host = if (idx > 0) target.substring(0, idx) else target
            val port = if (idx > 0) target.substring(idx + 1).toIntOrNull() ?: 443 else 443

            val up = Socket()
            upstream = up
            up.tcpNoDelay = true
            up.connect(InetSocketAddress(host, port), 5000)
            cout.write("HTTP/1.1 200 Connection established\r\n\r\n".toByteArray())
            cout.flush()

            val firstChunk = readFirst(cin) ?: return
            client.soTimeout = 0
            val uout = up.getOutputStream()
            if (firstChunk[0].toInt() == 0x16) {
                Desync.send(uout, firstChunk, strategy())
            } else {
                uout.write(firstChunk)
                uout.flush()
            }

            val t = thread(isDaemon = true) { pipe(up.getInputStream(), cout) }
            pipe(cin, uout)
            t.join(2000)
        } catch (_: Exception) {
        } finally {
            try { upstream?.close() } catch (_: Exception) {}
            try { client.close() } catch (_: Exception) {}
        }
    }

    private fun pipe(i: InputStream, o: java.io.OutputStream) {
        try {
            val buf = ByteArray(16384)
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                o.write(buf, 0, n)
                o.flush()
            }
        } catch (_: Exception) {
        }
    }
}
