package dev.dpitruck

import java.io.OutputStream

/** Приёмы, которыми можно отправить первый TLS-пакет (ClientHello), чтобы DPI не прочитал имя сайта (SNI). */
enum class Strategy(val label: String) {
    NONE("без обхода"),
    SPLIT_1("TCP split после 1 байта"),
    SPLIT_SNI("TCP split внутри SNI"),
    TLSREC_SNI("TLS-record split внутри SNI"),
    TLSREC_SPLIT("TLS-record + TCP split"),
    SPLIT_SNI_DELAY("TCP split в SNI + пауза");
}

object Desync {

    private fun u8(d: ByteArray, i: Int) = d[i].toInt() and 0xFF
    private fun u16(d: ByteArray, i: Int) = (u8(d, i) shl 8) or u8(d, i + 1)

    /** Возвращает [смещение имени хоста, длина] внутри ClientHello или null. */
    fun sniRange(d: ByteArray): IntArray? {
        try {
            if (d.size < 48 || u8(d, 0) != 0x16 || u8(d, 5) != 0x01) return null
            var p = 5 + 4 + 2 + 32
            p += 1 + u8(d, p)
            p += 2 + u16(d, p)
            p += 1 + u8(d, p)
            val extEnd = p + 2 + u16(d, p)
            p += 2
            while (p + 4 <= extEnd) {
                val type = u16(d, p)
                val len = u16(d, p + 2)
                if (type == 0) {
                    val nameLen = u16(d, p + 7)
                    return intArrayOf(p + 9, nameLen)
                }
                p += 4 + len
            }
        } catch (_: Exception) {
        }
        return null
    }

    /** Режет одну TLS-запись на две в точке cut (индекс в исходном буфере). */
    private fun recSplit(d: ByteArray, cut: Int): ByteArray? {
        if (d.size < 6 || u8(d, 0) != 0x16) return null
        val recLen = u16(d, 3)
        if (recLen != d.size - 5) return null
        val c = cut - 5
        if (c < 1 || c >= recLen) return null
        val r = recLen - c
        val out = ByteArray(d.size + 5)
        out[0] = d[0]; out[1] = d[1]; out[2] = d[2]
        out[3] = (c shr 8).toByte(); out[4] = c.toByte()
        System.arraycopy(d, 5, out, 5, c)
        val o2 = 5 + c
        out[o2] = d[0]; out[o2 + 1] = d[1]; out[o2 + 2] = d[2]
        out[o2 + 3] = (r shr 8).toByte(); out[o2 + 4] = r.toByte()
        System.arraycopy(d, 5 + c, out, o2 + 5, r)
        return out
    }

    private fun two(out: OutputStream, d: ByteArray, at: Int, delayMs: Long) {
        if (at <= 0 || at >= d.size) {
            out.write(d)
            return
        }
        out.write(d, 0, at)
        out.flush()
        Thread.sleep(if (delayMs > 0) delayMs else 10)
        out.write(d, at, d.size - at)
    }

    /** Отправляет первый пакет клиента по выбранной стратегии. */
    fun send(out: OutputStream, d: ByteArray, s: Strategy) {
        val sni = sniRange(d)
        val cut = if (sni != null) sni[0] + sni[1] / 2 else 1
        when (s) {
            Strategy.NONE -> out.write(d)
            Strategy.SPLIT_1 -> two(out, d, 1, 0)
            Strategy.SPLIT_SNI -> two(out, d, cut, 0)
            Strategy.SPLIT_SNI_DELAY -> two(out, d, cut, 150)
            Strategy.TLSREC_SNI -> out.write(recSplit(d, cut) ?: d)
            Strategy.TLSREC_SPLIT -> {
                val r = recSplit(d, cut)
                if (r == null) out.write(d) else two(out, r, cut, 0)
            }
        }
        out.flush()
    }
}
