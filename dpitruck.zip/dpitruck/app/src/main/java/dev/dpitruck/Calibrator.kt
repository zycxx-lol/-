package dev.dpitruck

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.telephony.TelephonyManager
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL

object Calibrator {

    /** Пробует открыть https://domain/ через временный прокси с заданной стратегией. */
    fun probe(domain: String, s: Strategy): Boolean {
        val proxy = LocalProxy { s }
        return try {
            proxy.start(0)
            val c = URL("https://$domain/").openConnection(
                Proxy(Proxy.Type.HTTP, InetSocketAddress("127.0.0.1", proxy.port))
            ) as HttpURLConnection
            c.connectTimeout = 5000
            c.readTimeout = 5000
            c.instanceFollowRedirects = false
            val code = c.responseCode
            c.disconnect()
            code > 0
        } catch (_: Exception) {
            false
        } finally {
            proxy.stop()
        }
    }

    /** Ключ сети: у каждого оператора / Wi-Fi свой DPI, поэтому и свой профиль. */
    fun networkKey(ctx: Context): String {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return "offline"
        val caps = cm.getNetworkCapabilities(net) ?: return "offline"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
                "cell:" + tm.networkOperatorName
            }
            else -> "other"
        }
    }
}
