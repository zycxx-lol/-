package dev.dpitruck

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var domain: EditText
    private lateinit var calBtn: Button
    private lateinit var proxyBtn: Button
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private var proxy: LocalProxy? = null

    private val prefs by lazy { getSharedPreferences("profiles", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "DPI Truck (тест)"
            textSize = 22f
        })

        domain = EditText(this).apply {
            setText("discord.com")
            hint = "Заблокированный домен для проверки"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        root.addView(domain)

        calBtn = Button(this).apply {
            text = "1. Калибровка под эту сеть"
            setOnClickListener { calibrate() }
        }
        root.addView(calBtn)

        proxyBtn = Button(this).apply {
            text = "2. Запустить прокси 127.0.0.1:1080"
            setOnClickListener { toggleProxy() }
        }
        root.addView(proxyBtn)

        logView = TextView(this).apply { textSize = 14f }
        scroll = ScrollView(this).apply { addView(logView) }
        root.addView(
            scroll,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0, 1f
            )
        )

        setContentView(root)
        log("Сеть: ${Calibrator.networkKey(this)}")
        log("Сохранённый профиль: ${currentStrategy().label}")
    }

    private fun log(msg: String) {
        runOnUiThread {
            logView.append(msg + "\n")
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    private fun currentStrategy(): Strategy {
        val name = prefs.getString(Calibrator.networkKey(this), null)
        return Strategy.values().firstOrNull { it.name == name } ?: Strategy.TLSREC_SNI
    }

    private fun calibrate() {
        val d = domain.text.toString().trim()
            .removePrefix("https://").removePrefix("http://").trimEnd('/')
        if (d.isEmpty()) {
            log("Введи домен")
            return
        }
        calBtn.isEnabled = false
        val key = Calibrator.networkKey(this)
        log("--- Калибровка: $d, сеть $key ---")
        thread {
            var best: Strategy? = null
            for (s in Strategy.values()) {
                val ok = Calibrator.probe(d, s)
                log((if (ok) "✓ " else "✗ ") + s.label)
                if (ok && best == null) best = s
            }
            when {
                best == null ->
                    log("Ничего не сработало. Вероятно, блок по IP или DNS, а не по DPI.")
                best == Strategy.NONE ->
                    log("Без обхода открывается: для этого домена DPI-блока нет.")
                else -> {
                    prefs.edit().putString(key, best.name).apply()
                    log("Выбрано и сохранено для $key: ${best.label}")
                }
            }
            runOnUiThread { calBtn.isEnabled = true }
        }
    }

    private fun toggleProxy() {
        val p = proxy
        if (p != null) {
            p.stop()
            proxy = null
            proxyBtn.text = "2. Запустить прокси 127.0.0.1:1080"
            log("Прокси остановлен")
            return
        }
        try {
            val np = LocalProxy { currentStrategy() }
            np.start(1080)
            proxy = np
            proxyBtn.text = "Остановить прокси"
            log("Прокси запущен, стратегия: ${currentStrategy().label}")
            log("Укажи HTTP-прокси 127.0.0.1:1080 в настройках Wi-Fi или в браузере.")
        } catch (e: Exception) {
            log("Не удалось запустить: ${e.message}")
        }
    }

    override fun onDestroy() {
        proxy?.stop()
        super.onDestroy()
    }
}
